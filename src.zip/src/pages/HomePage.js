import React from "react";
import { NavLink } from "react-router-dom";
import styled from "styled-components";
import Barlow from "../fonts/Barlow/Barlow-Medium.ttf";
import myImage from "../mvp-banner.png";

// Font yüklemesi için @font-face kullanımı

const FontFaceHomePage = styled.div`
  @font-face {
    font-family: "Barlow";
    src: url(${Barlow}) format("truetype");
    font-weight: normal;
    font-style: normal;
  }
`;

const StyledApp = styled.div`
  background-image: url(${myImage});
  background-size: cover;
  margin: auto;
  height: 100vh;
  overflow: hidden;
`;

const Container = styled.div`
  text-align: center;
  color: white;
  margin-top: 75px;
`;

const Title = styled.h1`
  font-family: "Barlow", sans-serif; /* Font yüklemesi burada yapılıyor */
  color: white;
  font-size: 40px;
  width: 25%;
  margin: 0 auto;
`;

const Button = styled.button`
  font-family: "Barlow", sans-serif; /* Font yüklemesi burada yapılıyor */
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background-color: #fdc913;
  border-radius: 20px;
  border: 2px solid transparent;
  color: black;
  margin: 50px auto;
  padding: 1em 2em;
  text-decoration: none;
`;

function HomePage() {
  return (
    <StyledApp>
      <FontFaceHomePage>
        <Container>
          <Title>KOD ACIKTIRIR, PİZZA DOYURUR</Title>
          <NavLink to="/pizza" style={{ textDecoration: "none" }}>
            <Button>ACIKTIM</Button>
          </NavLink>
        </Container>
      </FontFaceHomePage>
    </StyledApp>
  );
}

export default HomePage;
